package br.com.ibm.tudodebom;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication 
public class TudoDeBomApplication {

	public static void main(String[] args) {	
		SpringApplication.run(TudoDeBomApplication.class, args);}
		
}
