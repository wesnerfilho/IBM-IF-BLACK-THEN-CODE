package br.com.ibm.tudodebom.tudodebom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TudodebomApplication {

	public static void main(String[] args) {
		SpringApplication.run(TudodebomApplication.class, args);
	}

	
}

