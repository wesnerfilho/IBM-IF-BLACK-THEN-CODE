package br.com.ibm.tudodebom.tudodebom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TudodebomApplicationTests {

	@Test
	void contextLoads() {
	}

}
