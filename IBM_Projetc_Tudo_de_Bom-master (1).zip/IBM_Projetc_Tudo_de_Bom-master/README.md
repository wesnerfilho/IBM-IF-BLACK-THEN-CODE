# IBM_Projetc_Tudo_de_Bom
Sistema de gerenciamento de clientes e transações

LISTA DE ENDPOINTS

CLIENTE

[GET]  " /cliente" -> Listar todos os clientes
[POST]   " /cliente" -> Cadastrar um novo cliente
[PUT]  "/cliente" -> Atualizar cliente
[DELETE] "/cliente" -> Deletar um cliente

PRODUTO

[GET]  " /produto" -> Listar todos os produtos
[POST]   " /produto" -> Cadastrar um novo produto
[PUT]  "/produto" -> Atualizar produto
[DELETE] "/cliente" -> Deletar um produtote

PRODUTO

[GET]  " /transacoes" -> Listar todas as transações
[POST]   " /transacoes" -> Cadastrar uma nova transação


BANCO DE DADOS MY SQL
![blobhttpsweb whatsapp com271590f6-27d1-469c-b8ef-d1ed8a4f8454 (23)](https://user-images.githubusercontent.com/93411167/185110063-f15df4f5-a519-4b86-983f-1a57071ff9f3.png)
